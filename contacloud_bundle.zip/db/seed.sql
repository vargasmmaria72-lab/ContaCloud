INSERT INTO empresas (nombre,nit,regimen,moneda,ciudad) VALUES ('Café & Co','900123456-7','Responsable de IVA','COP','Bogotá');

INSERT INTO users (empresa_id,nombre,email,password_hash,rol) VALUES (1,'Admin Contacloud','admin@cafe.co','$2b$...hash','admin');

INSERT INTO cuentas (empresa_id,codigo,nombre,naturaleza,nivel) VALUES
(1,'1105','Caja','Deudora',1),
(1,'2105','Cuentas por pagar','Acreedora',1),
(1,'4105','Ventas','Acreedora',1);
