-- schema.sql (PostgreSQL)
CREATE TABLE empresas (
  id SERIAL PRIMARY KEY,
  nombre VARCHAR(200) NOT NULL,
  nit VARCHAR(50),
  regimen VARCHAR(100),
  moneda VARCHAR(10) DEFAULT 'COP',
  ciudad VARCHAR(100),
  creado_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  nombre VARCHAR(200) NOT NULL,
  email VARCHAR(200) UNIQUE NOT NULL,
  password_hash VARCHAR(512) NOT NULL,
  rol VARCHAR(50) DEFAULT 'colaborador',
  creado_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE cuentas (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  codigo VARCHAR(50) NOT NULL,
  nombre VARCHAR(200) NOT NULL,
  naturaleza VARCHAR(20),
  nivel INTEGER DEFAULT 1
);

CREATE TABLE transacciones (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  fecha DATE NOT NULL,
  descripcion TEXT,
  total NUMERIC(18,2),
  tipo VARCHAR(50),
  estado VARCHAR(20) DEFAULT 'pendiente',
  creado_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE asientos (
  id SERIAL PRIMARY KEY,
  transaccion_id INTEGER REFERENCES transacciones(id) ON DELETE CASCADE,
  cuenta_id INTEGER REFERENCES cuentas(id),
  debe NUMERIC(18,2) DEFAULT 0,
  haber NUMERIC(18,2) DEFAULT 0,
  descripcion TEXT
);

CREATE TABLE clientes (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  nombre VARCHAR(200),
  nit VARCHAR(80),
  email VARCHAR(200),
  direccion TEXT
);

CREATE TABLE facturas (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  cliente_id INTEGER REFERENCES clientes(id),
  fecha DATE,
  numero VARCHAR(100),
  subtotal NUMERIC(18,2),
  iva NUMERIC(18,2),
  total NUMERIC(18,2),
  estado VARCHAR(50) DEFAULT 'borrador'
);

CREATE TABLE bancos (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  nombre VARCHAR(200),
  cuenta_num VARCHAR(100),
  saldo NUMERIC(18,2) DEFAULT 0
);

CREATE TABLE movimientos_banco (
  id SERIAL PRIMARY KEY,
  banco_id INTEGER REFERENCES bancos(id) ON DELETE CASCADE,
  fecha DATE,
  descripcion TEXT,
  monto NUMERIC(18,2),
  tipo VARCHAR(20),
  conciliado BOOLEAN DEFAULT false
);

CREATE TABLE logs_auditoria (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  accion VARCHAR(100),
  tabla VARCHAR(100),
  registro_id INTEGER,
  info JSONB,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT now()
);
