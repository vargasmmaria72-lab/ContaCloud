# Contacloud — Paquete inicial

Contenido del bundle:
- static-site/index.html : Prototipo estático (lista para abrir en navegador)
- logo-contacloud.svg     : Logo SVG
- react-app/              : Esqueleto de proyecto React (src + package.json)
- express-server/         : Mock Express server con endpoints básicos
- db/schema.sql           : DDL PostgreSQL
- db/seed.sql             : Seeds demo
- api/openapi.yaml        : OpenAPI minimal
- LICENSE                 : MIT (por defecto)

## Instrucciones rápidas

Opción A — Abrir prototipo estático:
1. Extrae el ZIP y abre `static-site/index.html` en tu navegador.

Opción B — Levantar React (desarrollo local):
1. En `react-app/` ejecuta `npm install`.
2. Ejecuta `npm start` para el entorno de desarrollo (http://localhost:3000).

Opción C — Levantar servidor mock Express:
1. En `express-server/` ejecuta `npm install`.
2. Ejecuta `node server.js` (usa puerto 4000 por defecto).

Opción D — Base de datos:
- Ejecuta `db/schema.sql` en una instancia PostgreSQL y luego `db/seed.sql` para datos demo.

Si quieres, te doy el comando para crear el repo, docker-compose o despliegue en Render/Vercel.
