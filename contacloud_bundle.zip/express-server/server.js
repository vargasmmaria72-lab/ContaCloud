// Mock Express server for Contacloud (endpoints minimal)
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(bodyParser.json());

// In-memory demo data
let empresas = [{id:1,nombre:'Café & Co',nit:'900123456-7',moneda:'COP'}];
let facturas = [{id:1203,empresa_id:1,cliente_id:11,fecha:'2025-11-18',numero:'F-1023',subtotal:60000,iva:11400,total:71400,estado:'emitida'}];

app.post('/api/auth/login', (req,res)=>{
  const {email} = req.body;
  // Demo: always return a mock token
  res.json({access_token:'demo.jwt.token',expires_in:3600});
});

app.post('/api/empresas', (req,res)=>{
  const id = empresas.length + 1;
  const e = {id, ...req.body};
  empresas.push(e);
  res.status(201).json(e);
});

app.get('/api/empresas/:id/dashboard', (req,res)=>{
  const id = Number(req.params.id);
  const body = {
    empresa_id: id,
    saldo_disponible: 12450000,
    ingresos_30d: 35000000,
    egresos_30d: 22750000,
    porcentaje_conciliacion: 82
  };
  res.json(body);
});

app.post('/api/empresas/:id/facturas', (req,res)=>{
  const id = facturas.length + 1204;
  const payload = {...req.body, id};
  facturas.push(payload);
  res.status(201).json({factura_id: id, total: payload.items ? payload.items.reduce((s,i)=>s + (i.cantidad * i.precio_unitario * (1 + (i.iva||0))) ,0) : payload.total || 0, estado:'emitida'});
});

app.get('/api/empresas/:id/reportes/balance', (req,res)=>{
  const {fecha} = req.query;
  res.json({empresa_id:Number(req.params.id), fecha: fecha || new Date().toISOString().slice(0,10), activo:45000000, pasivo:21000000, patrimonio:24000000});
});

const port = process.env.PORT || 4000;
app.listen(port, ()=> console.log('Contacloud mock API listening on',port));
