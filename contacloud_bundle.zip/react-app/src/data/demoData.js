export const asientos = [
  {fecha:'2025-11-18', desc:'Venta factura F-1023', debe:'0', haber:'1.200.000'},
  {fecha:'2025-11-18', desc:'Compra insumos B-201', debe:'450.000', haber:'0'},
  {fecha:'2025-11-17', desc:'Pago nómina nómina-11', debe:'2.500.000', haber:'0'},
];

export const movimientos = [
  {fecha:'2025-11-18', monto:'-320.000'},
  {fecha:'2025-11-17', monto:'+1.200.000'},
  {fecha:'2025-11-15', monto:'-450.000'}
];
