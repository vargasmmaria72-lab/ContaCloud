import React from 'react';
export default function Pricing(){
  return (
    <section id="pricing">
      <h2>Precios</h2>
      <div className="price-grid" style={{marginTop:12}}>
        <div className="price-card">
          <div style={{fontWeight:700}}>Starter</div>
          <div style={{fontSize:20,fontWeight:700}}>$29 / mes</div>
          <ul style={{paddingLeft:16}}>
            <li>1 empresa</li>
            <li>Facturación básica</li>
            <li>Soporte email</li>
          </ul>
          <div style={{marginTop:12}}><button className="cta">Comenzar</button></div>
        </div>
        <div className="price-card">
          <div style={{fontWeight:700}}>Pro</div>
          <div style={{fontSize:20,fontWeight:700}}>$79 / mes</div>
          <ul style={{paddingLeft:16}}>
            <li>Hasta 5 empresas</li>
            <li>Conciliación</li>
            <li>Reportes fiscales</li>
          </ul>
          <div style={{marginTop:12}}><button className="cta">Pruébalo</button></div>
        </div>
        <div className="price-card">
          <div style={{fontWeight:700}}>Corporativo</div>
          <div style={{fontSize:20,fontWeight:700}}>Contacto</div>
          <ul style={{paddingLeft:16}}>
            <li>Multiempresa ilimitada</li>
            <li>API & SSO</li>
            <li>Soporte SLA</li>
          </ul>
          <div style={{marginTop:12}}><button className="cta">Contactar ventas</button></div>
        </div>
      </div>
    </section>
  )
}
