import React from 'react';
export default function ContactForm(){
  return (
    <section style={{marginTop:22}}>
      <div className="card">
        <h3>Contacto</h3>
        <p style={{color:'var(--muted)'}}>Solicita demo o consulta tributaria.</p>
        <form onSubmit={(e)=>{e.preventDefault(); alert('Gracias — demo solicitada') }}>
          <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
            <input required placeholder="Nombre" style={{padding:10,borderRadius:8,border:'1px solid #eef2f8',flex:1}} />
            <input required placeholder="Email" style={{padding:10,borderRadius:8,border:'1px solid #eef2f8',flex:1}} />
          </div>
          <textarea required placeholder="Mensaje" style={{width:'100%',marginTop:10,padding:10,borderRadius:8}} />
          <div style={{marginTop:10}}><button className="cta">Enviar</button></div>
        </form>
      </div>
    </section>
  )
}
