import React from 'react';
export default function Hero(){
  return (
    <section className="container hero">
      <div className="hero-left">
        <h1 className="h1">Contabilidad automática, informes listos y cumplimiento fiscal</h1>
        <p className="lead">Registra comprobantes, concilia bancos y genera estados financieros sin esfuerzo. Diseñado para contadores y PYMEs en LATAM.</p>
        <div style={{display:'flex',gap:12}}>
          <button className="cta">Comenzar prueba</button>
          <button style={{padding:'10px 14px',borderRadius:8}}>Ver demo</button>
        </div>
      </div>
      <div style={{width:420}}>
        <div className="card">
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
            <div>
              <div style={{fontSize:12,color:'var(--muted)'}}>Empresa</div>
              <div style={{fontWeight:700}}>Café & Co</div>
            </div>
            <div style={{background:'#eefaf5',color:'var(--accent)',padding:'6px 10px',borderRadius:20,fontWeight:700}}>Activo</div>
          </div>
          <div style={{marginTop:12,color:'var(--muted)'}}>Saldo disponible</div>
          <div style={{fontSize:22,fontWeight:700,marginTop:6}}>$ 12.450.000</div>
        </div>
      </div>
    </section>
  )
}
