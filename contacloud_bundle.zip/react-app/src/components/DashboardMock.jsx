import React from 'react';
import { asientos, movimientos } from '../data/demoData';

export default function DashboardMock(){
  return (
    <section id="dashboard" style={{marginTop:22}}>
      <h2>Demo panel contable</h2>
      <div style={{display:'grid',gridTemplateColumns:'1.6fr 1fr',gap:16,marginTop:12}}>
        <div>
          <div className="card" style={{height:200,display:'flex',alignItems:'center',justifyContent:'center'}}>Gráfica placeholder</div>

          <div style={{display:'flex',gap:12,marginTop:12}}>
            <div className="card" style={{flex:1}}>
              <div style={{fontWeight:700}}>Libro Diario (últimos asientos)</div>
              <table style={{width:'100%',marginTop:8}}>
                <thead><tr><th style={{textAlign:'left',padding:'8px 4px'}}>Fecha</th><th>Descripción</th><th>Debe</th><th>Haber</th></tr></thead>
                <tbody>
                  {asientos.map((a,i)=>(
                    <tr key={i}><td style={{padding:'8px 4px'}}>{a.fecha}</td><td>{a.desc}</td><td>{a.debe}</td><td>{a.haber}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="card" style={{width:260}}>
              <div style={{fontWeight:700}}>Movimientos bancarios</div>
              <table style={{width:'100%',marginTop:8}}>
                <thead><tr><th>Fecha</th><th>Monto</th></tr></thead>
                <tbody>
                  {movimientos.map((m,i)=>(
                    <tr key={i}><td style={{padding:'8px 4px'}}>{m.fecha}</td><td>{m.monto}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <aside>
          <div className="card">
            <div style={{fontWeight:700}}>Resumen mensual</div>
            <div style={{marginTop:8}}>Ingresos: <strong>$35.000.000</strong></div>
            <div style={{marginTop:8}}>Egresos: <strong>$22.750.000</strong></div>
            <div style={{marginTop:8}}>Utilidad: <strong>$12.250.000</strong></div>
            <div style={{marginTop:12}}><button style={{width:'100%',padding:10,borderRadius:8}}>Exportar reporte</button></div>
          </div>
          <div className="card" style={{marginTop:12}}>
            <div style={{fontWeight:700}}>Alertas</div>
            <ul style={{marginTop:8,color:'var(--muted)'}}>
              <li>Factura pendiente por conciliación: F-1023</li>
              <li>Cuenta corriente con saldo negativo</li>
            </ul>
          </div>
        </aside>
      </div>
    </section>
  )
}
