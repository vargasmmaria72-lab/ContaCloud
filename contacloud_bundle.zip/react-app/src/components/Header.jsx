import React from 'react';
export default function Header(){
  return (
    <header className="header">
      <div className="brand">
        <img src="/logo-contacloud.svg" alt="Contacloud" className="logo-img" />
        <div>
          <div style={{fontWeight:700}}>Contacloud</div>
          <div style={{fontSize:12,color:'var(--muted)'}}>Contabilidad en la nube</div>
        </div>
      </div>
      <nav className="nav">
        <a href="#features">Características</a>
        <a href="#pricing">Precios</a>
        <a href="#dashboard">Demo</a>
        <button className="cta">Pruébalo</button>
      </nav>
    </header>
  )
}
