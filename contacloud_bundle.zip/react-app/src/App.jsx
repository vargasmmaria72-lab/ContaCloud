import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Pricing from './components/Pricing';
import DashboardMock from './components/DashboardMock';
import ContactForm from './components/ContactForm';

export default function App(){
  return (
    <div className="app">
      <Header />
      <main>
        <Hero />
        <section className="container"><Pricing /></section>
        <section className="container"><DashboardMock /></section>
        <section className="container"><ContactForm /></section>
      </main>
      <footer className="footer">© {new Date().getFullYear()} Contacloud · Seguridad y cumplimiento básico</footer>
    </div>
  )
}
